package AEV2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Controlador {
	
	private Model model;
	private Vista vista;
	
	public Controlador(Model model, Vista vista) {
		this.model = model;
		this.vista = vista;
		
		vista.getBtnBuscar().addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				buscarPalabra();
			}
		});
		
		 vista.getBtnReemplazar().addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	                remplazarPalabra();
	            }
	        });
	}
	
	private void buscarPalabra() {
		String palabra = vista.getTextFieldBuscar();
		int cont = model.contarPalabra(palabra);
		JOptionPane.showInputDialog(vista, "La palabra " + palabra + " aparece " + cont + " veces.");
		
	}
	
	public void remplazarPalabra() {
		 String palabra = vista.getTextFieldBuscar();
	     String nuevaPalabra = vista.getTextFieldReemplazar();
	     String textoNuevo = model.remplazarPalabra(palabra, nuevaPalabra);
	     vista.setTextAreaModificado(textoNuevo);
	     
	     try {
			model.guardarFichero("nuevoFichero.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
