package AEV2;

import java.io.IOException;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Vista vista = new Vista();
			Model model = new Model();
			Controlador controlador = new Controlador(model, vista);
			
			try {
				model.leerFichero("AE02_T1_2_Streams_Groucho.txt");
				vista.setTextArea(model.returTexto());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
	}

}
