package AEV2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Model {
	
	String texto;
		
	public void leerFichero (String ruta) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader (ruta));
		StringBuilder sb = new StringBuilder();
		
		String linea;
		while((linea = br.readLine()) != null) {
			sb.append(linea).append("\n");
		}
		br.close();
		texto = sb.toString();
	}
	
	public String returTexto() {
		return texto;
	}
	
	public int contarPalabra(String palabra) {
		if (texto == null) {
			return 0;
		}
		
		String [] palabras = texto.split("\\s+");
		int cont = 0;
		for (String p : palabras) {
			if (p.equalsIgnoreCase(palabra)) {
				cont++;
			}
		}
		return cont;
	}
	
	public String remplazarPalabra (String antpalabra, String nuevpalabra) {
		if(!texto.equals(null)) {
			texto = texto.replaceAll(antpalabra, nuevpalabra);
		}
		return texto;
	}
	
	public void guardarFichero (String rutanueva) throws IOException {
		BufferedWriter bw = new BufferedWriter (new FileWriter (rutanueva));
		bw.write(texto);
		bw.close();
	}
}
