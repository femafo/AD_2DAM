package FileAct;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

public class Main7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		String path;
		String nextension;
		boolean continuar = true;
		String continuarsn;
		ArrayList <String> extension = new ArrayList <String> ();
		path = teclado.next();
		do {
			nextension = teclado.next();
			extension.add(nextension);
			System.out.println("Continuar s/n");
			continuarsn = teclado.next();
			if (continuarsn.equals("s")) {
				continuar = true;
			}
			if (continuarsn.equals("n")) {
				continuar = false;
			}
		}while(continuar == true);
		
		File ejercicio7 = new File(path);
		
		String aruta = ejercicio7.getAbsolutePath();
		String nombre = ejercicio7.getName();
		String ruta = ejercicio7.getPath();
		boolean existe = ejercicio7.exists();
		
		
		System.out.println(aruta);
		System.out.println(nombre);
		System.out.println(ruta);
		if (existe == true) {
			System.out.println("La ruta existe");
		}else {
			System.out.println("ERROR la ruta no existe");
		}
		
		for (String fextension : extension) {
			Filtro filtro = new Filtro (fextension);
			String [] nombre1 = ejercicio7.list(filtro); 
			for (int i = 0; i < nombre1.length; i++){
				System.out.println(nombre1[i]);
		}
		
		}
	}

}
