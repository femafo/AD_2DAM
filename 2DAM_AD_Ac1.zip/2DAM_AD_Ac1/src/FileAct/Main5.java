package FileAct;

import java.io.File;
import java.util.Scanner;

public class Main5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	Scanner teclado = new Scanner(System.in);
		String path;
		String extension;
		path = teclado.next();
		extension = teclado.next();
		File ejercicio5 = new File(path);
		Filtro filtro = new Filtro (extension); 
		String aruta = ejercicio5.getAbsolutePath();
		String nombre = ejercicio5.getName();
		String ruta = ejercicio5.getPath();
		boolean existe = ejercicio5.exists();
		String [] nombre1 = ejercicio5.list(filtro); 
		
		System.out.println(aruta);
		System.out.println(nombre);
		System.out.println(ruta);
		if (existe == true) {
			System.out.println("La ruta existe");
		}else {
			System.out.println("ERROR la ruta no existe");
		}
		
		for (int i = 0; i < nombre1.length; i++){
			System.out.println(nombre1[i]);
		}
		

	}

}
