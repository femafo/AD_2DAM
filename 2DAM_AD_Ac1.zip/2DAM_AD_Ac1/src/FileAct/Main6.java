package FileAct;

import java.io.File;
import java.util.Scanner;

public class Main6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		String path;
		String extension;
		path = teclado.nextLine();
		extension = teclado.nextLine();
		File ejercicio6 = new File(path);
		Filtro filtro = new Filtro (extension); 
		String aruta = ejercicio6.getAbsolutePath();
		String nombre = ejercicio6.getName();
		String ruta = ejercicio6.getPath();
		boolean existe = ejercicio6.exists();
		String [] nombre1 = ejercicio6.list(filtro); 
		
		System.out.println(aruta);
		System.out.println(nombre);
		System.out.println(ruta);
		if (existe == true) {
			System.out.println("La ruta existe");
		}else {
			System.out.println("ERROR la ruta no existe");
		}
		
		for (int i = 0; i < nombre1.length; i++){
			System.out.println(nombre1[i]);
		}
	}

}
