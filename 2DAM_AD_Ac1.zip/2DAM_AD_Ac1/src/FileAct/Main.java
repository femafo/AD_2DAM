package FileAct;

import java.io.File;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		File ejercicio1 = new File(".");
		System.out.println(ejercicio1);

	}

}
