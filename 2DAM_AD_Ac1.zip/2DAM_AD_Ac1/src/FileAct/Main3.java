package FileAct;

import java.io.File;
import java.util.Scanner;

public class Main3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		String filtro;
		filtro = teclado.next();
		File ejercicio3 = new File(filtro);
		String aruta = ejercicio3.getAbsolutePath();
		String nombre = ejercicio3.getName();
		String ruta = ejercicio3.getPath();
		boolean existe = ejercicio3.exists();
		
		System.out.println(aruta);
		System.out.println(nombre);
		System.out.println(ruta);
		System.out.println(existe);
	}

}
