package FileAct;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Main8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		String extension;
		String path;
		String nuevoarch;
		System.out.println("Dime una ruta");
		path = teclado.next();
		System.out.println("Dime un archivo");
		extension = teclado.next();
		
		File ejercicio8 = new File(path);
		Filtro filtro = new Filtro (extension);
		String [] nombre1 = ejercicio8.list(filtro);
		
		for (int i = 0; i < nombre1.length; i++){
			if (nombre1[i].equals(extension)) {
				nuevoarch = "copia_" + nombre1[i];
				File crearfile = new File (path, nuevoarch);
				boolean crear = false;
				try {
					crear = crearfile.createNewFile();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				if (crear == true) {
					System.out.println("Archivo creado");
					crear = false;
				}else {
					System.out.println("EROR, ARCHIVO NO CREADO");
				}
				
				crear = crearfile.delete();
				
				if (crear == true) {
					System.out.println("Archivo borrado");
					crear = false;
				}else {
					System.out.println("EROR, ARCHIVO NO BORRADO");
				}
				
					
				
			}
		}
	}

}
