package FileAct;

import java.io.File;
import java.util.Scanner;

public class Main4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		String filtro;
		filtro = teclado.next();
		File ejercicio4 = new File(filtro);
		String aruta = ejercicio4.getAbsolutePath();
		String nombre = ejercicio4.getName();
		String ruta = ejercicio4.getPath();
		boolean existe = ejercicio4.exists();
		
		
		
		System.out.println(aruta);
		System.out.println(nombre);
		System.out.println(ruta);
		if (existe == true) {
			System.out.println("La ruta existe");
		}else {
			System.out.println("ERROR la ruta no existe");
		}
	}

}
