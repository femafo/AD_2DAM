package FileAct;

import java.io.File;
import java.util.Scanner;

public class Main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		String filtro;
		filtro = teclado.next();
		File ejercicio2 = new File(filtro);
		String aruta = ejercicio2.getAbsolutePath();
		String nombre = ejercicio2.getName();
		String ruta = ejercicio2.getPath();
		
		System.out.println(aruta);
		System.out.println(nombre);
		System.out.println(ruta);
		
		
	}

}
