package AEV1;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		String ruta;
		File aev1;
		int opc;
		String nuevaCarpeta;
		String nombrearch;
		
		do {
		System.out.println("Dime la ruta del directorio al que desea acceder:");
		ruta = teclado.next();
		
		aev1 = new File (ruta);
		
		if(aev1.exists()) {
			do {
			System.out.println("¿Que desea hacer?\n1.-Mostrar informacion\n2.-Crear carpeta\n3.-Eliminar fichero/carpeta\n4.-Renombrar fichero/carpeta");
			opc = teclado.nextInt();
			
			switch (opc) {
			
			case 1:
				getInformacion(aev1);
				break;
				
			case 2:
				System.out.println("¿Que nombre desea ponerle?");
				nuevaCarpeta = teclado.next();
				File rutanuev = crearCarpeta(aev1, nuevaCarpeta);
				
				do {
				System.out.println("¿Desea crear un fichero?\n1.-Si\n2.-No");
				opc = teclado.nextInt();
				switch(opc) {
				
				case 1:
					System.out.println("¿Que nombre desea ponerle al archivo?");
					nombrearch = teclado.next();
					boolean creado = crearFichero(rutanuev, nombrearch);
					if (creado ==  true) {
						System.out.println("Archivo creado");
					}else {
						System.out.println("Error al crear el archivo");
					}
					break;
					
				case 2:
					System.out.println("Adios :)");
					break;
					
				default:
					System.out.println("Seleccione una opcion valida.");
				}
				}while(opc < 1 || opc > 2);
				
				break;
				
			case 3:
				break;
				
			case 4:
				break;
				
			default:
				System.out.println("Seleccione una opcion valida.");
			}
			
			}while(opc < 1 || opc > 5);
			
			
		}else {
			System.out.println("ERROR, la ruta indicada no existe, vuelva a intentarlo.");
		}
		
		}while(aev1.exists() == false);
		
	}
	
	public static void getInformacion(File ruta) {
		
		String absruta = ruta.getAbsolutePath();
		long ultimaModificacion = ruta.lastModified();
		Date fecha = new Date (ultimaModificacion);
		String oculto;
		if(ruta.isHidden()) {
			oculto = "Es oculto";
		}else {
			oculto = "No es oculto";
		}
		
		if(ruta.isFile() == true) {
			long tamanyoBytes = ruta.length();
			
			System.out.println(ruta.getName() + " - Archvio\n" + absruta + "\nUltima modificacion: " + fecha + "\n" + oculto + "\nMide:" + tamanyoBytes + " bytes");
			
		}
		
		if(ruta.isDirectory() == true) {
			File[] archivos = ruta.listFiles();
			long espacioLibre = ruta.getFreeSpace();
			long espacioDisponible = ruta.getUsableSpace();
			long espacioTotal = ruta.getTotalSpace();
			
			do {
			if (archivos != null) {
				System.out.println(ruta.getName() + " - Directorio\n" + absruta + "\nUltima modificacion: " + fecha + "\n" + oculto  + "\nNúmero de elementos en el directorio: " + archivos.length + "\nEspacio libre: " + espacioLibre + " bytes" + "\nEspacio disponible: " + espacioDisponible + " bytes" + "\nEspacio total: " + espacioTotal + " bytes");
            } else {
                System.out.println("No se pudo acceder al contenido del directorio.");
            }
			}while (archivos == null);
			
		}
	}
	
	public static File crearCarpeta(File ruta, String nombre) {
		File rutacarp = new File (ruta + "/" + nombre);
		boolean creado = rutacarp.mkdir();
		if(creado == true) {
			System.out.println("Carpeta creada correctamente");
		}else {
			System.out.println("No se ha podido crear la carpeta");
		}
		return rutacarp;
	}
	
	public static boolean crearFichero(File ruta, String nombre) {
		boolean creado = false;
		File rutaarch = new File (ruta + "/" + nombre);
		try {
			creado = rutaarch.createNewFile();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return creado;
	}

}
