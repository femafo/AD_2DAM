package ad.futbolistasxml;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class HelloController implements Initializable {

    @FXML
    private TextField ano_id;
    @FXML
    private Button previo_button;
    @FXML
    private TextField id_jugador;
    @FXML
    private TextField equipo_id;
    @FXML
    private TextField posicion_id;
    @FXML
    private Button posterior_button;
    @FXML
    private TextField id_nombre;

    FutbolistaModel fm = new FutbolistaModel();
    ArrayList<Futbolista> futboleros = new ArrayList<>();
    int posicion = 0;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            fm.LeerXML("futboleros.xml");

            Futbolista futbolista = new Futbolista();
            futbolista = fm.Read(posicion);
            id_jugador.setPromptText(String.valueOf(futbolista.getId()));
            id_nombre.setPromptText(String.valueOf(futbolista.getNombre()));
            equipo_id.setPromptText(String.valueOf(futbolista.getEquipo()));
            posicion_id.setPromptText(String.valueOf(futbolista.getPosicion()));
            ano_id.setPromptText(String.valueOf(futbolista.getAno()));
            for (Futbolista f : futboleros){
                System.out.println(f.getNombre() + "" + f.getEquipo());
            }

        } catch (SAXException e) {
            throw new RuntimeException(e);
        } catch (ParserConfigurationException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    public void posteriorbutton(ActionEvent actionEvent) {
        posicion++;
        if (posicion == 3){
            posicion--;
        }
        mostrarJugador();
    }

    @FXML
    public void previobutton(ActionEvent actionEvent) {
        posicion--;
        if (posicion == -1){
            posicion++;
        }
        mostrarJugador();
    }

    public void mostrarJugador(){
        try {
            fm.LeerXML("futboleros.xml");

            Futbolista futbolista = new Futbolista();
            futbolista = fm.Read(posicion);
            id_jugador.setPromptText(String.valueOf(futbolista.getId()));
            id_nombre.setPromptText(String.valueOf(futbolista.getNombre()));
            equipo_id.setPromptText(String.valueOf(futbolista.getEquipo()));
            posicion_id.setPromptText(String.valueOf(futbolista.getPosicion()));
            ano_id.setPromptText(String.valueOf(futbolista.getAno()));
            for (Futbolista f : futboleros){
                System.out.println(f.getNombre() + "" + f.getEquipo());
            }

        } catch (SAXException e) {
            throw new RuntimeException(e);
        } catch (ParserConfigurationException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}