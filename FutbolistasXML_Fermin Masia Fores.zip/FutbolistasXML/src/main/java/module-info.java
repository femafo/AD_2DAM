module ad.futbolistasxml {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.xml;


    opens ad.futbolistasxml to javafx.fxml;
    exports ad.futbolistasxml;
}